# XML Pseudocode

 * Enable xml external entities = true

  * External entities
      * customer
      * manager
  
#### There are a few ways to go about this so use your creativity!  
#### Remember there are different options for different languages!
#### Give us your ideas in a checklist on OWASPhero.pdf!
