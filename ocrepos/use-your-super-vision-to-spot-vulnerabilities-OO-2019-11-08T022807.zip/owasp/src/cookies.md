# Create a Cookie Pseudocode

 ### Login validation from login page 
    if loginvalidated() = true
    then createsessioncookie().

### createsessioncookie() function
   * create session ID using chronological numbers
   * set session ID to never expire
   * save session ID in the database
   * put session ID and login credentials in cookie

What do you think we can use to make our session cookies more secure?
Let us know with your checklist in the **OWASPhero.pdf** answer sheet!
 
