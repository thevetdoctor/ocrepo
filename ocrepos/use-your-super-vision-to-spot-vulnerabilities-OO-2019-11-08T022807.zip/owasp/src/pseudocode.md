# Welcome our Code Design!

## Look at the provided pseudocode and provide us some ideas on how to securely code our site!
