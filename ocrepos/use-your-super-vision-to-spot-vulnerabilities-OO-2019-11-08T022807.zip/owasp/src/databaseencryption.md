# Database Encryption Pseudocode

* Database Encryption Ruleset
  * Use SHA1 hash algorithm for the passwords
  * Give all DBAs and the IT department full access for all database functions
  
 #### What do you think we can change in the ruleset to make the web app more secure?
 #### Is there a better hash algorithm?
 #### Who should have full access to the database?
 #### Please let us know what you think in the OWASPhero.pdf document!
  
