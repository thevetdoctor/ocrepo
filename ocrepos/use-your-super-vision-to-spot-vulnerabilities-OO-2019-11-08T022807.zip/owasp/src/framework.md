# What do you think of the Framework we will use?

## Framework
* Node.js
* Mongo.db with MVC 
* HTTP requests with Ajax
* Loopback

#### What do I need to know in order to ensure my framework components do not have vulnerabilities?  
#### How can I ensure that we can keep track of new vulnerabilities to our web app in the future?
### Give us your ideas on the OWASPhero.pdf document!
