# Requests Pseudocode

* GET Requests
  * Use HTTP
  * GET customer with username/password
  * GET list of customers
  * GET new customer signup
  * GET change customer password
  
 #### Do you think there might be other request types we can use to secure our requests?
 #### Please provide your ideas in OWASPhero.pdf!
