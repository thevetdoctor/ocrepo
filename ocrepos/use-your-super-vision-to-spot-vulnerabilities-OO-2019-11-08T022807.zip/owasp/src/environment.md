# Lock down your Environment!

* Environment
  * Windows Server
  * Dell server with firewall
  * Web application firewall (WAF)
  * Configuration files, passwords and source code access requires a username and password
  
#### Although as web developers, we typically don't configure our own environment, what can we suggest 
#### to our systems and network administrators to ensure our web application will not be compromised?

### Let us know on OWASPhero.pdf!
