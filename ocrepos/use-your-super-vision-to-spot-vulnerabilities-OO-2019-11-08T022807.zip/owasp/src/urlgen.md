# URL Generation Pseudocode

* Dynamic URL Generation
  * Generate URL with Session ID after loginvalidate()
  * loginvalidate() only used on initial login screen
  * User database attribute values for subdirectory websites
  
 #### Do you have any ideas on how we can generate our URLs to make them more secure?
 #### Put your ideas in the OWASPhero.pdf form!
  

