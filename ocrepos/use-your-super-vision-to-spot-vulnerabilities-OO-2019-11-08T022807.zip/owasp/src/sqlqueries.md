# SQL Queries Pseudocode

* Dynamic SQL queries
  * login validation query to database
  * search items in database
  
#### What are some options you have to make it secure?  
#### Can you use another type of SQL query? 
#### What can you do with the dynamic sql query to make it more secure?
#### Provide your feedback in the OWASPhero.pdf document!
